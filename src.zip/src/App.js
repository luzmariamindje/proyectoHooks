
import './App.css';
import Productos from './Componentes/Productos';

function App() {
  return (
    <div className="App">
      <Productos></Productos>
      
      <button type="submit" onclick="">get</button>
    </div>
  );
}

export default App;
