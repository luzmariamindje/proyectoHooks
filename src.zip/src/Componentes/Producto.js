import React from "react";
    class Producto extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            productos: [],

    }
}
componentDidMount(){
    console.log("inicio")
    fetch('https://dummyjson.com/products')
    .then(response => response.json())
    .then(data => {
        console.log(data)
    this.setState({productos:data.products})

    })
    .catch(error => {
    console.log(error)
    });
    
}
render(){
    return(<div>
        
    </div>)
}

}
export default Producto